using UnityEngine;
[SerializeField]
public struct PlayerNEtwordInfo
{
    //public string name;
    public float HP;
    public float MP;
    public float score;
}
/**
 */
